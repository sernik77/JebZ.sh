(function() {
    // Find the first contenteditable element in the document
    var editableElement = document.querySelector('[contenteditable="true"]');
    
    // Check if an editable element was found
    if (editableElement) {
        // Create a new paragraph element
        var newParagraph = document.createElement('p');
        // Add some text to the new paragraph
        newParagraph.textContent = '[color=#B41A9D]dupa[/color]';
        
        // Append the new paragraph to the contenteditable element
        editableElement.appendChild(newParagraph);
        
        console.log('Text added to the contenteditable element.');
    } else {
        console.error('No contenteditable element found.');
    }
})();
