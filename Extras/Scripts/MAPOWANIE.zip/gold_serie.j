// Array of badgeable IDs
const badgeableIds = ['ID1', 'ID2', 'ID3', 'ID4', /*...*/];

// Dynamically obtained values
const csrfToken = 'DYNAMICALLY_OBTAINED_CSRF_TOKEN';
const xsrfToken = 'DYNAMICALLY_OBTAINED_XSRF_TOKEN';
const sessionId = 'DYNAMICALLY_OBTAINED_SESSION_ID';
const pkId = 'DYNAMICALLY_OBTAINED_PK_ID';

// Construct the cookies string dynamically
const cookies = `_pk_id.1.b292=${pkId}; XSRF-TOKEN=${xsrfToken}; jbzdy_session=${sessionId};`;

// Function to send the POST request
const sendPostRequest = async (id) => {
  try {
    const response = await fetch(`https://jbzd.com.pl/badge/content/give/${id}`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9,pl-PL;q=0.8,pl;q=0.7',
        'Content-Type': 'application/json;charset=UTF-8',
        'Cookie': cookies,
        'DNT': '1',
        'Origin': 'https://jbzd.com.pl',
        'Referer': 'https://jbzd.com.pl/',
        'Sec-CH-UA': '"Chromium";v="116", "Not)A;Brand";v="24", "Google Chrome";v="116"',
        'Sec-CH-UA-Mobile': '?0',
        'Sec-CH-UA-Platform': '"Linux"',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
        'X-CSRF-Token': csrfToken,
        'X-XSRF-TOKEN': xsrfToken,
      },
      body: JSON.stringify({ type: 'gold' }),
      credentials: 'include',
    });

    const data = await response.json();
    console.log(data);
  } catch (error) {
    console.error('Error:', error);
  }
};

// Send POST requests for each badgeable ID with a 5s delay between each request
for (const id of badgeableIds) {
  setTimeout(() => {
    sendPostRequest(id);
  }, 5000 * badgeableIds.indexOf(id));
}
