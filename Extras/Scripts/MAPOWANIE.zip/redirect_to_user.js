// Step 1: Prompt for the username
var username = prompt("Please enter your username:");

// Step 2: Redirect to the user's comment page
window.location.href = "https://jbzd.com.pl/uzytkownik/" + username + "/komentarze";
