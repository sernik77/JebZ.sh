var scrollDownInterval = setInterval(function() {
    window.scrollBy(0, 100); // Scrolls down 100 pixels every 100 milliseconds
}, 100);

// To stop the scrolling, you would call clearInterval(scrollDownInterval) in the console.
