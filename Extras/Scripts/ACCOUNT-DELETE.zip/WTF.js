// TEN KOD Z JAKIEGOŚ POWODU WYPLUWA PEŁEN LOG

function fetchTagData() {
  fetch("https://btloader.com/tag?aax_id=AAX60SDR3&domain=jbzd.com.pl&ver=1.2&upapi=true", {
    referrer: "https://jbzd.com.pl/",
    referrerPolicy: "strict-origin-when-cross-origin",
    body: null,
    method: "GET",
    mode: "cors",
    credentials: "omit"
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return response.json(); // or .text(), depending on the response
  })
  .then(data => {
    console.log(data);
  })
  .catch(error => {
    console.error('There was a problem with your fetch operation:', error);
  });
}
