// Find and click the "tutaj" link
const tutajLink = document.querySelector('a[data-v-14d28b74]');
if (tutajLink) {
    tutajLink.click();
} else {
    console.log('Tutaj link not found');
}

// Then, find and click the "Tak" span
setTimeout(() => {
    const yesSpan = document.querySelector('span:contains("Tak")');
    if (yesSpan) {
        yesSpan.click();
    } else {
        console.log('"Tak" span not found');
    }
}, 100); // Adjust delay as needed
