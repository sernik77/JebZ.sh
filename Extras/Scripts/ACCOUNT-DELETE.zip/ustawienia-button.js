// Find and click the "ustawienia" link
const settingsLink = document.querySelector('.profile-nav-link[href="/uzytkownik/ustawienia"]');
if (settingsLink) {
    settingsLink.click();
} else {
    console.log('Settings link not found');
}
