// Inject a script that has access to the page's JavaScript context
const scriptContent = `
(function() {
    // Try to access the variable or object directly
    var targetObject = window.someGlobalObjectThatContainsTheData; // Adjust this to match how the data is stored/accessed in the page

    if (targetObject && targetObject.name === "Shumi") {
        // If found, send a message to the content script
        window.postMessage({ type: "FOUND_TARGET", data: targetObject }, "*");
    }
})();
`;

const script = document.createElement('script');
script.textContent = scriptContent;
(document.head || document.documentElement).appendChild(script);
script.remove();

// Listen for messages from the injected script
window.addEventListener("message", function(event) {
    // Check if the message is from your injected script
    if (event.source == window && event.data.type && event.data.type == "FOUND_TARGET") {
        console.log("Target object found:", event.data.data);
        // Execute your specific code here
    }
});
