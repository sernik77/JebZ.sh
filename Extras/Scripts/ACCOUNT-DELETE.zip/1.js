fetch("https://btloader.com/tag?aax_id=AAX60SDR3&domain=jbzd.com.pl&ver=1.2&upapi=true", {
  "referrer": "https://jbzd.com.pl/",
  "referrerPolicy": "strict-origin-when-cross-origin",
  "body": null,
  "method": "GET",
  "mode": "cors",
  "credentials": "omit"
});
