(function() {
    // Replace 'SPECIFIED_USERNAME' with the username you're checking for
    var specifiedUsername = 'shumi';
    
    // Function to execute when the specified username matches
    function customCodeToExecute() {
        console.log('Username matches. Executing custom code.');
        
// Find the link by its data attribute and text content
const link = Array.from(document.querySelectorAll('a[data-v-14d28b74]')).find(el => el.textContent.trim() === 'tutaj');

// Check if the link is found and click it
if (link) {
    link.click();
} else {
    console.log('Link not found');
}

    }
    
    // Find the user's username from the page
    var profileLinkElement = document.querySelector('.profile-header a[href*="/uzytkownik/"]');
    if (profileLinkElement) {
        var profileUrl = profileLinkElement.getAttribute('href');
        var username = profileUrl.split('/uzytkownik/')[1];
        
        // Check if the found username matches the specified one
        if (username === specifiedUsername) {
            customCodeToExecute();
        } else {
            console.log('Username does not match.');
        }
    } else {
        console.log('Profile link not found.');
    }
})();
