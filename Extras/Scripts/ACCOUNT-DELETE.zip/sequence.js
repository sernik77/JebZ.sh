// Function to perform actions with a delay between them
function performActions() {
  // Click the "ustawienia" link
  const settingsLink = Array.from(document.querySelectorAll('.profile-nav-link')).find(el => el.textContent.trim() === 'Ustawienia');
  if (settingsLink) {
    settingsLink.click();
  } else {
    console.log('Settings link not found');
    return; // Stop if the link is not found
  }

  // Wait a bit for the page or state to change, then click "tutaj"
  setTimeout(() => {
    const tutajLink = Array.from(document.querySelectorAll('a[data-v-14d28b74]')).find(el => el.textContent.trim() === 'tutaj');
    if (tutajLink) {
      tutajLink.click();
    } else {
      console.log('Tutaj link not found');
      return; // Stop if the link is not found
    }

    // Wait a bit more, then click "Tak"
    setTimeout(() => {
      const yesSpan = Array.from(document.querySelectorAll('span')).find(el => el.textContent.trim() === 'Tak');
      if (yesSpan) {
        yesSpan.click();
      } else {
        console.log('Yes span not found');
      }
    }, 100); // Adjust time as needed

  }, 100); // Adjust time as needed based on your page's behavior
}

performActions();
