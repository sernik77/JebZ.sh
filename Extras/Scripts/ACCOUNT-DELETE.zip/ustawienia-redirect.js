// Find the link by its class and text content
const link = Array.from(document.querySelectorAll('.profile-nav-link')).find(el => el.textContent.trim() === 'Ustawienia');

// Check if the link is found
if (link) {
    // Create a new click event
    const event = new MouseEvent('click', {
        'view': window,
        'bubbles': true,
        'cancelable': true
    });

    // Clone the link to modify its properties
    const clonedLink = link.cloneNode(true);
    clonedLink.setAttribute('target', '_blank'); // Set target to _blank to open in a new tab
    document.body.appendChild(clonedLink); // Temporarily add the cloned link to the document to make it part of the DOM

    // Dispatch the event to the cloned link
    clonedLink.dispatchEvent(event);

    // Remove the cloned link from the document
    document.body.removeChild(clonedLink);
} else {
    console.log('Link not found');
}
