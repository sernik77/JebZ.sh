fetch("https://mc.yandex.com/watch/49064765?wmode=7&page-url=https%3A%2F%2Fjbzd.com.pl%2F&page-ref=https%3A%2F%2Fjbzd.com.pl%2Fuzytkownik%2Fustawienia&charset=utf-8&uah=chu%0A%22Not%3DA%3FBrand%22%3Bv%3D%2299%22%2C%22Chromium%22%3Bv%3D%22118%22%0Acha%0Ax86%0Achb%0A64%0Achf%0A118.0.5993.70%0Achl%0A%22Not%3DA%3FBrand%22%3Bv%3D%2299.0.0.0%22%2C%22Chromium%22%3Bv%3D%22118.0.5993.70%22%0Achm%0A%3F0%0Achp%0ALinux%0Achv%0A6.1.0&browser-info=pv%3A1%3Avf%3Arrsvvwew1t7vq6pawluowr6j%3Afu%3A0%3Aen%3Autf-8%3Ala%3Aen-US%3Av%3A1261%3Acn%3A1%3Adp%3A0%3Als%3A1486318804700%3Ahid%3A950994859%3Az%3A60%3Ai%3A20240312022723%3Aet%3A1710206843%3Ac%3A1%3Arn%3A222815114%3Arqn%3A206%3Au%3A1705284806113222179%3Aw%3A1144x1043%3As%3A1920x1080x24%3Ask%3A0.8999999761581421%3Ads%3A0%2C0%2C103%2C1%2C4%2C0%2C%2C%2C%2C%2C%2C%2C%3Aco%3A0%3Acpf%3A1%3Ans%3A1710206842865%3Agi%3AR0ExLjMuOTc2Mjg5NzczLjE3MDUyODQ4MDc%3D%3Aadb%3A2%3Arqnl%3A1%3Ast%3A1710206844%3At%3AJbzd.com.pl%20-%20najgorsze%20obrazki%20w%20internecie!&t=gdpr(14)clc(0-0-0)rqnt(1)aw(1)rcm(0)cdl(na)ti(1)", {
  "headers": {
    "accept": "*/*",
    "accept-language": "en-US,en;q=0.9",
    "sec-ch-ua": "\"Not=A?Brand\";v=\"99\", \"Chromium\";v=\"118\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Linux\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site"
  },
  "referrer": "https://jbzd.com.pl/",
  "referrerPolicy": "strict-origin-when-cross-origin",
  "body": null,
  "method": "GET",
  "mode": "cors",
  "credentials": "omit"
});
