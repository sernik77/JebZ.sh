// Find the link by its data attribute and text content
const link = Array.from(document.querySelectorAll('a[data-v-14d28b74]')).find(el => el.textContent.trim() === 'tutaj');

// Check if the link is found and click it
if (link) {
    link.click();
} else {
    console.log('Link not found');
}
