// Find the span element by its text content
const span = Array.from(document.querySelectorAll('span')).find(el => el.textContent.trim() === 'Tak');

// Check if the span is found and click it
if (span) {
    span.click();
} else {
    console.log('Span not found');
}
