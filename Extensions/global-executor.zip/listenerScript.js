if (!window.myScriptLoaded) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === "executeClick") {
            clickSubmitButton();
        }
    });

	// Define the function to be executed when receiving the correct message
	function clickSubmitButton() {
    var buttons = document.querySelectorAll('button.btn-submit[type="submit"]');
    var targetButton = Array.from(buttons).find(button => button.textContent.trim() === "Dodaj");
    
    if(targetButton) {
        targetButton.click();
        console.log('Button clicked successfully!');
    } else {
        console.error('Button not found');
    }
}
    window.myScriptLoaded = true; // Set the flag to prevent duplicate listeners
}

