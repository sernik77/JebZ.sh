document.getElementById('executeScript').addEventListener('click', () => {
    // Query all tabs with the specified domain
    chrome.tabs.query({url: "*://*.jbzd.com.pl/*"}, function(tabs) {
        tabs.forEach(tab => {
            // Inject the script into each matching tab
            chrome.scripting.executeScript({
                target: {tabId: tab.id},
                files: ['listenerScript.js']
            }, () => {
                // After ensuring the script is injected, send the message to each tab
                chrome.tabs.sendMessage(tab.id, {action: "executeClick"});
            });
        });
    });
});
