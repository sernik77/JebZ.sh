chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if(tab.url && tab.url.includes("jbzd.com.pl")) {
        chrome.scripting.executeScript({
          target: {tabId: tab.id},
          function: clickSubmitButton
        });
      }
    });
  });
});

function clickSubmitButton() {
  var buttons = document.querySelectorAll('button.btn-submit[type="submit"]');
  var targetButton = Array.from(buttons).find(button => button.textContent.trim() === "Dodaj");
  
  if(targetButton) {
    targetButton.click();
    console.log('Button clicked successfully!');
  } else {
    console.error('Button not found');
  }
}
