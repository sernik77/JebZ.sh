// Find and click the element
let userVoteLink = Array.from(document.querySelectorAll('a.user-vote')).find(el => el.textContent.trim() === '+');
if(userVoteLink) {
    userVoteLink.click();
} else {
    console.log('Element not found.');
}

// Redirect after clicking (or after a set timeout to ensure actions are complete)
setTimeout(() => {
    // This example just logs to console. You would navigate or signal background.js here.
    console.log("Would navigate to the next URL here.");
}, 1000); // Adjust delay as needed
