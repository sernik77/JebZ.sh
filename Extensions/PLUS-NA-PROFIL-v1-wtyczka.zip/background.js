const urls = ["https://jbzd.com.pl/uzytkownik/serainox", "https://jbzd.com.pl/uzytkownik/chuj98", "https://jbzd.com.pl/uzytkownik/removekebab88", "https://jbzd.com.pl/uzytkownik/wyjadaczmuzguf", "https://jbzd.com.pl/uzytkownik/kraverek", "https://jbzd.com.pl/uzytkownik/chujwiekto", "https://jbzd.com.pl/uzytkownik/vilgax", "https://jbzd.com.pl/uzytkownik/angrydraconequus"]; // Add your URLs here
let currentUrlIndex = 0;

function openNextUrl() {
  if (currentUrlIndex < urls.length) {
    chrome.tabs.create({ url: urls[currentUrlIndex] }, function(tab) {
      chrome.tabs.executeScript(tab.id, { file: 'content.js' });
    });
    currentUrlIndex++;
  } else {
    console.log("Finished processing URLs.");
  }
}

chrome.runtime.onInstalled.addListener(() => {
  openNextUrl(); // Start the process when the extension is installed/loaded
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url === urls[currentUrlIndex - 1]) {
    // Assuming content.js triggers a navigation, wait for it to complete, then open next URL
    setTimeout(openNextUrl, 1000); // Adjust delay as needed
  }
});
