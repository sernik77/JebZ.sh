// Simulate clicking on the file input element
document.querySelector('input[type="file"]').click();
