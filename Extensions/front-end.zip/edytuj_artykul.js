"[color=#B41A9D]aaa[/color]"

========================================

// Find the content-editable element
var editableElement = document.querySelector('[contenteditable="true"]');

// Check if the element exists and add text to it
if (editableElement) {
    editableElement.innerHTML += "<p> New Text Here </p>"; // Add your new text
    console.log('Text added.');
} else {
    console.error('Content-editable element not found.');
}


===============================


function addTextToEndOfContentEditable(selector, text) {
    // Find the content-editable element using the provided CSS selector
    var editableElement = document.querySelector(selector);

    // Check if the element exists
    if (editableElement) {
        // Use insertAdjacentText to insert the text at the 'beforeend' position,
        // which means right before the end of the element's content.
        editableElement.insertAdjacentText('beforeend', text);

        console.log('Text added.');
    } else {
        console.error('Content-editable element not found.');
    }
}

// Example usage:
// This will add the text 'aaa' to the end of the first content-editable element found.
// Replace 'selector' with the actual selector that matches your content-editable element.
// For example, if you're targeting a content-editable body, the selector might be 'body[contenteditable="true"]'
addTextToEndOfContentEditable('body[contenteditable="true"]', 'aaa');
