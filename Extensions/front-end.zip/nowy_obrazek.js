var divElement = document.querySelector('div.hybrid-type-selector-option');
if (divElement) {
  var clickEvent = new MouseEvent('click', {
    bubbles: true,
    cancelable: true,
    view: window,
  });
  divElement.dispatchEvent(clickEvent);
  console.log('Div element emulated click event.');
} else {
  console.error('Div element not found.');
}
