function clickTekstDiv() {
    // Find the <div> element that contains the text "Tekst"
    var divs = document.querySelectorAll('div.hybrid-type-selector-option');
    var tekstDiv = Array.from(divs).find(div => div.textContent.includes('Tekst'));

    if (tekstDiv) {
        // Create a new click event
        var clickEvent = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window
        });

        // Dispatch the click event on the <div> element
        tekstDiv.dispatchEvent(clickEvent);

        console.log('Clicked on <div> containing "Tekst".');
    } else {
        console.error('<div> containing "Tekst" not found.');
    }
}

// Call the function to click the <div> element
clickTekstDiv();
