function addExampleTags(tags) {
    // Find the input element for adding new tags
    var inputElement = document.querySelector('input.ti-new-tag-input');

    if (!inputElement) {
        console.error('Tag input element not found.');
        return;
    }

    // Function to simulate typing and submitting a tag
    function typeAndSubmitTag(tag) {
        // Simulate typing the tag
        inputElement.value = tag;
        // Create and dispatch an 'input' event (to mimic the user typing)
        var inputEvent = new Event('input', { bubbles: true });
        inputElement.dispatchEvent(inputEvent);

        // Simulate pressing Enter to submit the tag
        var enterKeyEvent = new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', code: 'Enter', keyCode: 13 });
        inputElement.dispatchEvent(enterKeyEvent);
    }

    // Iterate over the tags and add them
    tags.forEach(tag => {
        // Wait a short time before adding each tag to simulate typing
        setTimeout(() => typeAndSubmitTag(tag), 500);
    });
}

// Example usage: Add some tags
addExampleTags(['ExampleTag1', 'ExampleTag2', 'ExampleTag3']);
