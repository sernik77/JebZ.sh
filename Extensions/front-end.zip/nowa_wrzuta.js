var buttonElement = document.querySelector('button.button-add.add');
if (buttonElement) {
  var clickEvent = new Event('click');
  buttonElement.dispatchEvent(clickEvent);
  console.log('Button clicked.');
} else {
  console.log('Button element not found.');
}
