// Function to click the button element
function clickButtonElement() {
    var buttonElement = document.querySelector('button.button-add.add');
    if (buttonElement) {
        var clickEvent = new Event('click');
        buttonElement.dispatchEvent(clickEvent);
        console.log('Button clicked.');
    } else {
        console.log('Button element not found.');
    }
}

// Function to click the div element
function clickDivElement() {
    var divElement = document.querySelector('div.hybrid-type-selector-option');
    if (divElement) {
        var clickEvent = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
        });
        divElement.dispatchEvent(clickEvent);
        console.log('Div element emulated click event.');
    } else {
        console.error('Div element not found.');
    }
}

// Function to simulate clicking on the file input element
function clickFileInputElement() {
    var fileInputElement = document.querySelector('input[type="file"]');
    if (fileInputElement) {
        fileInputElement.click();
        console.log('File input element clicked.');
    } else {
        console.error('File input element not found.');
    }
}

// Execute the functions in sequence with 1s delay between each
clickButtonElement(); // Click the button element immediately

setTimeout(() => {
    clickDivElement(); // Click the div element after 1s
    setTimeout(() => {
        clickFileInputElement(); // Click the file input element after another 1s
    }, 1000);
}, 1000);
