function clickHumorSpan() {
    // Find the <span> element that contains the text "Humor"
    var spans = document.querySelectorAll('span[data-v-366138de]');
    var humorSpan = Array.from(spans).find(span => span.textContent.trim() === 'Humor');

    if (humorSpan) {
        // Create a new click event
        var clickEvent = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window
        });

        // Dispatch the click event on the <span> element
        humorSpan.dispatchEvent(clickEvent);

        console.log('Clicked on <span> containing "Humor".');
    } else {
        console.error('<span> containing "Humor" not found.');
    }
}

// Call the function to click the <span> element
clickHumorSpan();
