// Find the input element by its ID
var titleInputElement = document.getElementById('title');

// Check if the element exists
if (titleInputElement) {
    // Set the value of the input element
    titleInputElement.value = 'Example Title';
    console.log('Title set to "Example Title".');
} else {
    console.error('Title input element not found.');
}
