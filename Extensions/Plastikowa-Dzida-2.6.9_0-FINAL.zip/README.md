# Zdełysowiona platynowa 2.6.9
> By SerniX <3

### Changelog:
- Wyjebałem klucz i fingerprint do aktualizacji przez Google WebStore
- Zdeminifikowałem kod (jest w miare czytelny)
- Podmieniłem popup :D (kliknij ikonkę załadowanej wtyczki by go obczaić)
- Podmieniłem ikonkę na lepszą
