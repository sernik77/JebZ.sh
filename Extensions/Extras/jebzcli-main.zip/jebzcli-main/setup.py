from setuptools import setup, find_packages

setup(
    name='libzdy',
    version='1.0',
    author='itokajo',
    packages=find_packages(include=['libzdy', 'libzdy.*']),
    install_requires=['selenium', 'python-dotenv', 'SpeechRecognition', 'google-cloud-speech', 'pydub'],
    entry_points={
        'console_scripts': [
            'jebzcli = libzdy:run'
        ]
    }
)
