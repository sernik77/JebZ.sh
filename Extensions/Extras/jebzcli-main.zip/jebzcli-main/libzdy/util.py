import os
import ssl
import time
from urllib.request import urlretrieve

import speech_recognition
from pydub import AudioSegment
from selenium.webdriver.remote.webdriver import WebDriver as RemoteWebDriver
from selenium.common.exceptions import NoSuchElementException, NoSuchFrameException, TimeoutException

from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait


log_user_context = None


def log(*objs, **kwargs) -> None:
    if log_user_context is not None:
        return print(f"[JEBZCLI] ({log_user_context}) -", *objs, **kwargs)
    print("[JEBZCLI] -", *objs, **kwargs)


def get_session_string(username: str) -> str | None:
    if not os.path.exists(os.getenv("JEBZCLI_SESSION_STORAGE")):
        return None

    with open(os.getenv("JEBZCLI_SESSION_STORAGE"), "r") as f:
        for line in f.readlines():
            data = line.split("|")
            if data[0] == username:
                return data[1].replace("\n", "")

    return None


def validate_logged_in(driver: RemoteWebDriver) -> bool:
    driver.get("https://jbzd.com.pl")
    try:
        driver.find_element(By.CSS_SELECTOR, "form.box-sign.tab-login")
    except NoSuchElementException:
        return True

    return False


def login(driver: RemoteWebDriver, username: str, password: str) -> bool:
    driver.get("https://jbzd.com.pl/logowanie")
    log(f"Logging in...")
    form = driver.find_element(By.CSS_SELECTOR, ".auth-view-login form.box-sign")
    form.find_element(By.NAME, "login").send_keys(username)
    form.find_element(By.NAME, "password").send_keys(password)
    form.find_element(By.CLASS_NAME, "btn-submit").click()

    try:
        log('Checking for captcha...')
        WebDriverWait(driver, 1).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'iframe[title~="Test"]')))
        recaptcha_iframe = driver.find_element(By.CSS_SELECTOR, 'iframe[title~="Test"]')

        driver.switch_to.frame(recaptcha_iframe)

        audio_button = WebDriverWait(driver, 1).until(
            EC.element_to_be_clickable((By.ID, 'recaptcha-audio-button')))
        time.sleep(0.5)  # Często za szybko klika i się buguje, stąd ten sleep
        audio_button.click()

        audio_link = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '.rc-audiochallenge-tdownload-link')))
        audio_link = audio_link.get_attribute('href')

        tmp_loc = os.getenv('JEBZCLI_TMP') or os.path.expanduser('~/.jebzcli/tmp')
        tmp_mp3_path = os.path.join(tmp_loc, 'audio.mp3')
        tmp_wav_path = os.path.join(tmp_loc, 'audio.wav')

        ssl._create_default_https_context = ssl._create_unverified_context
        urlretrieve(audio_link, tmp_mp3_path)
        AudioSegment.from_mp3(tmp_mp3_path).export(tmp_wav_path, format='wav')
        os.remove(tmp_mp3_path)

        recognizer = speech_recognition.Recognizer()
        with speech_recognition.AudioFile(tmp_wav_path) as source:
            audio = recognizer.record(source)
            text = recognizer.recognize_google_cloud(audio, language='en-US')
            log(f'Detected challenge text: {text}')

        result_input = driver.find_element(By.ID, 'audio-response')
        result_input.send_keys(text)
        result_input.send_keys(Keys.ENTER)

        os.remove(tmp_wav_path)
    except (NoSuchElementException, NoSuchFrameException, TimeoutException) as e:
        log("No captcha to solve or error occured, checking if logged in...")

    print("Waiting for page to change after login...")
    # Podczas operacji na kapczy zmienialiśmy kontekst na iframe,
    # trza się upewnić że jesteśmy z powrotem na głównym oknie
    driver.switch_to.window(driver.window_handles[0])
    WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.CSS_SELECTOR, ".button-add.add")))

    print("Verifying if logged in...")
    try:
        driver.find_element(By.CSS_SELECTOR, "form.box-sign.tab-login")
    except NoSuchElementException:
        return True

    return False
