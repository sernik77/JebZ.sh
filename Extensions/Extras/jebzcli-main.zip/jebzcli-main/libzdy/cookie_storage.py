import pickle
import os


cookie_storage_path = os.getenv('JEBZCLI_SESSION_STORAGE') or os.path.expanduser('~/.jebzcli/sessions')
if not os.path.exists(cookie_storage_path):
    os.makedirs(cookie_storage_path, exist_ok=True)


def session_exists(username: str) -> bool:
    return os.path.exists(os.path.join(cookie_storage_path, f'{username}.pkl'))


def save_session(username: str, cookies: list):
    with open(os.path.join(cookie_storage_path, f'{username}.pkl'), 'wb') as f:
        pickle.dump(cookies, f)


def load_session(username: str) -> list:
    if not session_exists(username):
        return []

    with open(os.path.join(cookie_storage_path, f'{username}.pkl'), 'rb') as f:
        return pickle.load(f)
