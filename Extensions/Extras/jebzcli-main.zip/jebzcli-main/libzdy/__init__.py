import argparse
import platform

import os
from selenium import webdriver
from dotenv import load_dotenv
import libzdy.util
import libzdy.cookie_storage
import libzdy.command


if platform.system().lower() == 'darwin':
    os.environ['PATH'] += os.pathsep + '/opt/homebrew/bin'

if os.path.exists('.env'):
    load_dotenv()


def run():
    parser = argparse.ArgumentParser(prog='jebzcli')
    parser.add_argument(
        '--web-driver', '-wd',
        type=str, help='web browser driver to perform automation with',
        choices=['safari', 'chrome', 'firefox'],
        default='chrome'
    )
    parser.add_argument(
        '--headless', '-hl',
        help='run the browser in headless mode',
        action='store_true'
    )
    parser.add_argument(
        '--accounts-file', '-af',
        type=argparse.FileType('r'),
        help='file containing accounts to use for automation in format login:password separated by newline',
    )
    parser.add_argument(
        '--account', '-a',
        type=str,
        help='login:password for the account to use for automation',
    )
    subparsers = parser.add_subparsers(title='Available actions to be performed by the bot', help='additional help')
    command.like_post.register(subparsers)
    command.comment.register(subparsers)
    command.example_js.register(subparsers)

    args = parser.parse_args()

    if not args.accounts_file and not args.account:
        raise ValueError('You must provide either accounts file or account')

    if args.accounts_file and args.account:
        raise ValueError('You must provide either accounts file or account, not both')

    match args.web_driver:
        case 'safari':
            options = webdriver.SafariOptions()
            driver_class = webdriver.Safari
        case 'chrome':
            options = webdriver.ChromeOptions()
            driver_class = webdriver.Chrome
        case 'firefox':
            options = webdriver.FirefoxOptions()
            driver_class = webdriver.Firefox
        case _:
            raise ValueError('Unknown web driver')

    if args.headless:
        options.add_argument('--headless')

    driver = driver_class(options=options)

    if args.accounts_file:
        accounts = args.accounts_file.read().splitlines()
    else:
        accounts = [args.account]

    for account in accounts:
        util.log_user_context = None
        if len(driver.get_cookies()) > 0:
            util.log("Clearing all browser cookies")
            driver.delete_all_cookies()

        username, password = account.split(':')
        util.log_user_context = username
        cookies = cookie_storage.load_session(username)
        if len(cookies) > 0:
            util.log("Loading session cookies")
            for cookie in cookies:
                driver.add_cookie(cookie)

        if not util.validate_logged_in(driver):
            logged_in = util.login(driver, username, password)
            if not logged_in:
                util.log("Failed to log in")
                continue

        args.func(args, driver)

        util.log("Saving session cookies")
        cookie_storage.save_session(username, driver.get_cookies())
