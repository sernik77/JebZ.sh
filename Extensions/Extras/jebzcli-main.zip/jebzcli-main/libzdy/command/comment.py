import argparse

from selenium.webdriver.remote.webdriver import WebDriver as RemoteWebDriver


def register(subparsers) -> None:
    parser = subparsers.add_parser('comment', help='Post a comment')
    parser.add_argument(
        '--post-id', '-p',
        type=str,
        required=True,
        help='ID of the post.\nFormat: 0000000/slug-name'
    )
    parser.add_argument(
        '--comment', '-c',
        type=str,
        required=True,
    )
    parser.set_defaults(func=run)


def run(args: argparse.Namespace, driver: RemoteWebDriver):
    pass
