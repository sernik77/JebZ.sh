import argparse

from selenium.common import TimeoutException
from selenium.webdriver.remote.webdriver import WebDriver as RemoteWebDriver

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

from libzdy import util


def register(subparsers) -> None:
    parser = subparsers.add_parser('like_post', help='Like a post')
    parser.add_argument(
        '--post-id', '-p',
        type=str,
        required=True,
        help='ID of the post.\nFormat: 0000000/slug-name'
    )
    parser.set_defaults(func=run)


def run(args: argparse.Namespace, driver: RemoteWebDriver):
    driver.get("https://jbzd.com.pl/obr/%s" % args.post_id)

    try:
        util.log("Waiting for plus button...")
        plus_button = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '.article-actions-action.plus-type')))
    except TimeoutException:
        util.log("Failed to find plus button")
        return

    if 'active' in plus_button.get_attribute('class').split(' '):
        util.log(f"Post {args.post_id} already liked")
        return

    plus_button.click()

    try:
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '.article-actions-action.plus-type.active')))
    except TimeoutException:
        util.log("Failed to like post")
        return

    util.log(f"Post {args.post_id} liked successfully")
