import argparse

from selenium.webdriver.common.alert import Alert
from selenium.webdriver.remote.webdriver import WebDriver as RemoteWebDriver

import time
from libzdy import util


def register(subparsers) -> None:
    parser = subparsers.add_parser('example_js', help='Example of using JS in the browser')
    parser.set_defaults(func=action)


def action(args: argparse.Namespace, driver: RemoteWebDriver):
    driver.execute_script(
        """
            alert("hellow");
        """)
    util.log("Shown alert in browser, waiting for 3 seconds...")
    time.sleep(3)
    util.log("Dismissing alert...")
    Alert(driver).dismiss()
