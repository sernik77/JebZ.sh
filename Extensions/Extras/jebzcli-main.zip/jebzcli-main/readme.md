1. `python -m venv venv`

2. `python setup.py install` lub develop

Ustaw dane w .env lub wjeb envy w systemie

3. `jebzcli -h`

Example usage