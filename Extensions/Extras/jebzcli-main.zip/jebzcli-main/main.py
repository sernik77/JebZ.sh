from libzdy import run

# Ten pliczek to w zasadzie do debugu mam, żeby sprawdzić czy wszystko działa
if __name__ == '__main__':
    run()

