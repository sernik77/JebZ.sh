document.getElementById('executeScript').addEventListener('click', () => {
    // Query all tabs that have the specified domain in their URL
    chrome.tabs.query({url: "*://jbzd.com.pl/*"}, (tabs) => {
        tabs.forEach((tab) => {
            // Execute the script for each tab found
            chrome.scripting.executeScript({
                target: {tabId: tab.id},
                files: ['clickSubmitButton.js']
            });
        });
    });
});
