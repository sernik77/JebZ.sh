// clickSubmitButton.js
var buttons = document.querySelectorAll('button.btn-submit[type="submit"]');
var targetButton = Array.from(buttons).find(button => button.textContent.trim() === "Dodaj");

if(targetButton) {
  targetButton.click();
  console.log('Button clicked successfully!');
} else {
  console.error('Button not found');
}
