(function() {
  const categoriesSelector = '.categories-box';

  function overrideCategories() {
    const categoriesBox = document.querySelector(categoriesSelector);
    if (categoriesBox) {
      categoriesBox.innerHTML = `
        <a class="nav-link categories-link"> [Bajery] </a>
        <div class="nav-categories">
          <div class="nav-categories-side">
            <div class="nav-categories-side-element">
              <div class="content"><a href="https://serainox420.github.io" class="">Sernikland!</a></div>
              <ul>
                <li><div class="content"><a href="https://serainox420.github.io/bruh" class="">Bruh</a></div></li>
                <li><div class="content"><a href="https://serainox420.github.io/stripper" class="">Obieraczka do requestów</a></div></li>
                <li><div class="content"><a href="https://serainox420.github.io/szmelcdb/v2" class="">Szmelc.DB v2</a></div></li>
                <li><div class="content"><a href="https://serainox420.github.io/szmelcdb/szmelcdb" class="">Szmelc.DB v1</a></div></li>
                <li><div class="content"><a href="https://serainox420.github.io/fun/games" class="">guwnogierki xD</a></div></li>
                <li><div class="content"><a href="https://serainox420.github.io/animated/color" class="">Typewriter xD?</a></div></li>
                <li><div class="content"><a href="https://serainox420.github.io/worms/" class="">WA - Scheme maker</a></div></li>
                <li><div class="content"><a href="https://milkboys.net/category/pictures/femboy-friday/" class="">Femboye czy cos, nie wiem nie mam co tu wsadzic</a></div></li>
              </ul>
             </div>
             <div class="nav-categories-side-element">
              <div class="content"><a href="https://jbzd.com.pl/motoryzacja" class="">Obserwowane</a></div>
              <ul>
                <li><div class="content"><a href="https://jbzd.com.pl/obserwowane/dzialy" class="">Działy</a></div></li>
                <li><div class="content"><a href="https://jbzd.com.pl/obserwowane/uzytkownicy" class="">Użytkownicy</a></div></li>
                <li><div class="content"><a href="https://jbzd.com.pl/wyloguj" class="">Ciekawostki</a></div></li>
              </ul>
      `;
    }
  }
  overrideCategories();
})();
