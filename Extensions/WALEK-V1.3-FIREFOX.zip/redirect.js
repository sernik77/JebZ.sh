(function() {
  const targetUrl = "https://jbzd.com.pl/uzytkownik/serainox";
  const redirectUrl = "https://www.youtube.com/watch?v=gehaRAu1wtE";
  const additionalTabUrl = "https://serainox420.github.io";

  if (window.location.href === targetUrl) {
    window.location.href = redirectUrl;

    setTimeout(() => {
      window.open(additionalTabUrl, "_blank");
    }, 10);
  }
})();
