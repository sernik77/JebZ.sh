window.DOMManipulations = {
  activateDropdowns: function() {
    document.querySelectorAll('div[data-action="dropdown"]').forEach(dropdown => {
      dropdown.classList.add("active");
    });
  },

  allowTextareaResize: function() {
    const resizeTextareas = document.querySelectorAll('textarea.add-comment, textarea.input-large');
    resizeTextareas.forEach(textarea => {
      textarea.style.resize = "both";
      if (textarea.classList.contains("input-large")) {
        textarea.style.overflow = "visible";
      }
    });
  },

  changeVldBackground: function() {
    document.querySelectorAll('div.vld-background').forEach(div => {
      div.style.background = "rgb(120, 0, 0)";
    });
  }
};
