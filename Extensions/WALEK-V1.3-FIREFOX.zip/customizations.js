window.Customizations = {
  customizeRecommendations: function() {
    const recommendedSection = document.querySelector('.recommended');
    if (recommendedSection) {
      recommendedSection.innerHTML = 
        `<h3 class="recommended-title">Polecane</h3>
        <div class="recommendations">
          <div class="recommendation">
            <a href="https://jbzd.com.pl/obr/2385703/ruchanie">
              <img src="https://i.imgur.com/5mgOAye.png" alt="Ruchanie">
              <span class="recommendation-title">Ruchanie?</span>
            </a>
          </div>
          <div class="recommendation">
            <a href="https://darkmemes.pl">
              <img src="https://i.imgur.com/O3kA6aW.png" alt="Darkmemes.pl">
              <span class="recommendation-title">Darkmemes.pl ~ Nie należy do ruska <3</span>
            </a>
          </div>
          <div class="recommendation">
            <a href="https://serainox420.github.io">
              <img src="https://i.imgur.com/i7LOfZn.png" alt="Custom Image 3">
              <span class="recommendation-title">Adminy go nienawidzą! - Kliknij i sprawdź</span>
            </a>
          </div>
        </div>`;
    }
  }
};
