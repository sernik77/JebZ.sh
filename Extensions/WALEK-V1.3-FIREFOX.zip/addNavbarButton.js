(function() {
  const navbarSelector = '.nav-left';
  const buttonImageUrl = "https://i.imgur.com/7udlgCl.png";
  const redirectUrl = "https://jbzd.com.pl";
  const searcherSelector = '#searcher';

  function addNavbarButton() {
    const navbar = document.querySelector(navbarSelector);
    const searcher = document.querySelector(searcherSelector);

    if (navbar) {
      // Add 20px margin to the right of .nav-left
      navbar.style.marginRight = "50px";
      navbar.style.marginLeft = "50px";

      // Create a new anchor element for the button
      const newButton = document.createElement("a");
      newButton.href = redirectUrl;
      newButton.className = "ass";

      // Create the image element
      const imgElement = document.createElement("img");
      imgElement.src = buttonImageUrl;
      imgElement.alt = "Button Image";
      imgElement.style.width = "35%";
      imgElement.style.height = "35%";

      // Append image to the anchor, then add the anchor to the navbar
      newButton.appendChild(imgElement);
      navbar.prepend(newButton); // Add the new button to the start of nav-left
    }

    if (searcher) {
      // Add 20px margin to the right of the searcher element
      searcher.style.marginLeft = "69px";
      searcher.style.marginRight = "-25px";
    }
  }

  // Run the function on page load
  addNavbarButton();
})();
