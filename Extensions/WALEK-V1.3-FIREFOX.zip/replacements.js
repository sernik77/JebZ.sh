window.Replacements = {
  // Load configurations from GitHub URL or local file
  async loadConfig() {
    const githubUrl = "https://raw.githubusercontent.com/serainox420/JBZD-Data/refs/heads/personal/bolec-do-dzidy/replacements-config.json";
    let response;

    try {
      // Attempt to fetch from GitHub
      response = await fetch(githubUrl);
      if (!response.ok) throw new Error("GitHub config not found.");
      console.log("Configuration loaded from GitHub.");
    } catch (error) {
      console.warn("Failed to load config from GitHub, attempting local config. Error:", error);

      // Fallback to local file
      try {
        response = await fetch(chrome.runtime.getURL("replacements-config.json"));
        if (!response.ok) throw new Error("Local config not found.");
        console.log("Configuration loaded from local file.");
      } catch (localError) {
        console.error("Failed to load configuration from both GitHub and local file:", localError);
        return;
      }
    }

    // Parse and assign the configuration if successful
    this.config = await response.json();
  },

  // Replace images based on the configuration
  replaceImages() {
    const imageMap = this.config.imageReplacements;
    Object.entries(imageMap).forEach(([originalSrc, newSrc]) => {
      document.querySelectorAll(`img[src="${originalSrc}"]`).forEach(img => {
        img.src = newSrc;
      });
    });
  },

  // Replace icons based on the configuration
  replaceIcons() {
    const iconMap = this.config.iconReplacements;
    Object.entries(iconMap).forEach(([originalSrc, newSrc]) => {
      document.querySelectorAll(`img[src*="${originalSrc}"]`).forEach(img => {
        img.src = newSrc;
      });
    });
  },

  // Replace nickname text and color based on the configuration
  replaceNicknames() {
    const nicknames = this.config.nicknames;

    document.querySelectorAll('.article-author-name, .user-name').forEach(element => {
      Object.entries(nicknames).forEach(([nickname, { replacementText, color }]) => {
        if (new RegExp(`\\b${nickname}\\b`).test(element.textContent)) {
          element.innerHTML = element.innerHTML.replace(new RegExp(`\\b${nickname}\\b`, "g"), replacementText);
          element.style.color = color;
        }
      });
    });
  },

  // Replace avatar images based on the configuration
  replaceAvatars() {
    const avatars = this.config.avatarReplacements;
    Object.entries(avatars).forEach(([originalSrc, newSrc]) => {
      document.querySelectorAll(`img[src="${originalSrc}"]`).forEach(img => {
        img.src = newSrc;
      });
    });
  },

  // Initialize replacements and set up observers for dynamically loaded content
  async init() {
    await this.loadConfig();

    if (!this.config) {
      console.error("Configuration not loaded; exiting initialization.");
      return;
    }

    console.log("Starting replacements...");
    this.replaceImages();
    this.replaceIcons();
    this.replaceNicknames();
    this.replaceAvatars();

    // Observe dynamically loaded comments
    const commentsWrapper = document.querySelector(".article-comments-wrapper");
    if (commentsWrapper) {
      console.log("Setting up MutationObserver for comments...");
      const observer = new MutationObserver(() => {
        this.replaceNicknames();
        this.replaceAvatars();
      });
      observer.observe(commentsWrapper, { childList: true, subtree: true });
    } else {
      console.warn("Comments wrapper not found, observer not attached.");
    }
  }
};

// Initialize replacements when content script loads
window.Replacements.init();
