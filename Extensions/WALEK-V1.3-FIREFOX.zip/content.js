(async () => {
  const settings = await new Promise((resolve) => {
    chrome.storage.local.get(["settings"], (data) => {
      resolve(data.settings || {
        toggleReplacements: true,
        activateDropdowns: true,
        allowTextareaResize: true,
        changeVldBackground: true,
        customizeRecommendations: true,
        replaceNavLogo: true,
        replaceMikroblogLink: true,
        commentEnhancer: true,
      });
    });
  });

  // Only initialize replacements if the toggle is enabled
  if (settings.toggleReplacements) {
    await window.Replacements.init();
  }

  // Run other functionalities conditionally based on settings
  if (settings.activateDropdowns) window.DOMManipulations.activateDropdowns();
  if (settings.allowTextareaResize) window.DOMManipulations.allowTextareaResize();
  if (settings.changeVldBackground) window.DOMManipulations.changeVldBackground();
  if (settings.customizeRecommendations) window.Customizations.customizeRecommendations();
  if (settings.replaceNavLogo) window.Navigation.replaceNavLogo();
  if (settings.replaceMikroblogLink) window.Navigation.replaceMikroblogLink();

  // Trigger the comment enhancer if enabled
  if (settings.commentEnhancer) CommentEnhancer.initialize();
})();
