window.Navigation = {
  replaceNavLogo: function() {
    const navLogo = document.querySelector('a[href="https://jbzd.com.pl"].nav-logo');
    if (navLogo) {
      navLogo.remove();
      const newLogoLink = document.createElement('a');
      newLogoLink.href = "https://www.youtube.com/watch?v=MZuXseHGghg";
      newLogoLink.className = "nav-logo";

      const newLogoImage = document.createElement('img');
      newLogoImage.src = "https://i.imgur.com/7udlgCl.png";
      newLogoImage.alt = "";
      newLogoImage.style.width = "33%";
      newLogoImage.style.height = "33%";

      newLogoLink.appendChild(newLogoImage);
      document.querySelector('.nav-left-option').prepend(newLogoLink);
    }
  },

  replaceMikroblogLink: function() {
    const mikroblogLink = document.querySelector('a[href="/mikroblog/gorace"]');
    if (mikroblogLink) {
      const randomOptions = [
        "Spedalatorium", "Grota Analnej Rozkoszy", "Suteren Matki Kurwarasa",
        "Wstęp tylko w podwójnej gumie!", "Wylęgarnia AIDS", "Darmowy DOXBin",
        "Spedalone Ryje", "UWAGA! CWELĄ!", "Lepiej pilnuj dupy", "Najlepsi kumple Kurwyrasa",
        "Fapfolder twojej starej", "Gej Bar", "Glory Hole Dzidy",
        "Serbski sracz na CPN'ie", "Miblo blogi, Makro zjeby"
      ];
      const randomText = randomOptions[Math.floor(Math.random() * randomOptions.length)];

      // Determine the URL with a 90% or 10% probability
      const redirectUrl = Math.random() < 0.9
        ? "https://jbzd.com.pl/mikroblog/"
        : "https://szmelc.com";

      mikroblogLink.href = redirectUrl;
      mikroblogLink.innerHTML = `<img src="https://i.imgur.com/ztM81D7.png" style="width: 45%; height: 80%;"> ${randomText}`;

      // Apply styles to keep the text on one line and increase horizontal space
      mikroblogLink.style.whiteSpace = "nowrap";
      mikroblogLink.style.display = "inline-block";
      mikroblogLink.style.padding = "0 10px"; // Add some padding for extra horizontal space
      mikroblogLink.style.maxWidth = "200px"; // Set a max width to prevent overflow if needed
    }
  }
};
