const CommentEnhancer = (function() {
  // Inject CSS styling for comment elements
  const style = document.createElement('style');
  style.textContent = `
    .comment-plus-count {
        color: green;
        font-weight: bold;
        margin-right: 3px;
        margin-left: 10px;
        font-size: 14px;
    }
    .comment-score-value {
        color: #333;
        padding: 0px 3px;
        border-radius: 1px;
        font-weight: bold;
        font-size: 14px;
    }
    .comment-minus-count {
        color: red;
        font-weight: bold;
        margin-left: 3px;
        font-size: 14px;
    }
  `;
  document.head.appendChild(style);

  function getContentID() {
    const url = window.location.href;
    const match = url.match(/\/obr\/(\d+)\//);
    return match ? match[1] : null;
  }

  // Recursive function to inject plus/minus values for comments and their children (replies)
  function injectCommentData(comment, retryCount = 3) {
    const { id: commentId, score, plus, minus, children = [] } = comment;
    console.log(`Injecting data for Comment ID: ${commentId} | Score: ${score} | Plus: ${plus} | Minus: ${minus}`);

    // Find the main or nested comment element by looking for <a> with the comment ID
    const commentAnchor = document.querySelector(
      `.comment-wrapper a[name="komentarz-${commentId}"], .comment-wrapper.comment-sub a[name="komentarz-${commentId}"]`
    );

    if (commentAnchor) {
      const scoreContainer = commentAnchor.closest('.comment-wrapper, .comment-wrapper.comment-sub')?.querySelector('.comment-score');

      if (scoreContainer) {
        scoreContainer.querySelectorAll('.comment-plus-count, .comment-minus-count, .comment-score-value').forEach(el => el.remove());

        // Create and inject plus, score, and minus elements
        const plusElement = document.createElement('span');
        plusElement.className = 'comment-plus-count';
        plusElement.textContent = `+${plus}`;

        const scoreElement = document.createElement('span');
        scoreElement.className = 'comment-score-value';
        scoreElement.textContent = `|`;

        const minusElement = document.createElement('span');
        minusElement.className = 'comment-minus-count';
        minusElement.textContent = `-${minus}`;

        scoreContainer.appendChild(plusElement);
        scoreContainer.appendChild(scoreElement);
        scoreContainer.appendChild(minusElement);
      } else {
        console.warn(`Score container not found for comment ID: ${commentId}`);
      }
    } else if (retryCount > 0) {
      setTimeout(() => injectCommentData(comment, retryCount - 1), 500);
    } else {
      console.warn(`Comment element not found for comment ID: ${commentId} after retries`);
    }

    children.forEach(childComment => injectCommentData(childComment));
  }

  async function fetchComments() {
    const contentID = getContentID();
    if (!contentID) {
      console.warn("Content ID not found. This page may not have comments.");
      return;
    }

    // Send a message to the background script to fetch comments
    chrome.runtime.sendMessage({ action: "fetchComments", contentID }, (response) => {
      if (response && response.success) {
        const comments = response.data?.pagination?.data;
        if (Array.isArray(comments) && comments.length > 0) {
          comments.forEach(comment => injectCommentData(comment, 3));
        } else {
          console.warn("No comments found or data is not in the expected format.");
        }
      } else {
        console.error("Error fetching comments:", response?.error);
      }
    });
  }

  function observeNewComments(retryCount = 10) {
    const commentsContainer = document.querySelector(".comments");

    if (!commentsContainer && retryCount > 0) {
      console.warn("Comments container not found. Retrying...");
      setTimeout(() => observeNewComments(retryCount - 1), 500);
      return;
    } else if (!commentsContainer) {
      console.error("Comments container not found after multiple attempts.");
      return;
    }

    const observer = new MutationObserver((mutationsList) => {
      for (const mutation of mutationsList) {
        if (mutation.type === "childList" && mutation.addedNodes.length > 0) {
          mutation.addedNodes.forEach((node) => {
            if (node instanceof HTMLElement && (node.matches(".comment") || node.matches(".comment-wrapper.comment-sub"))) {
              const commentId = node.getAttribute("data-comment-id");
              if (commentId) {
                injectCommentData({ id: commentId }, 3); // Inject data for newly added comments
              }
            }
          });
        }
      }
    });

    observer.observe(commentsContainer, { childList: true, subtree: true });
    console.log("Observer started for dynamically loading comments.");
  }

  return {
    initialize: function() {
      fetchComments();
      observeNewComments();
    }
  };
})();
