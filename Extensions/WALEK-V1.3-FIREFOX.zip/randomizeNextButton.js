(function() {
  const buttonSelector = 'a.pagination-next';
  const phrases = [
    "???",
    "Wypierdalam",
    "Parostatkiem w piękny rejs",
    "Zaskocz mnie",
    "Aaa chuj",
    "Dobra dawaj",
    "Zapnij pasy",
    "Zabaw mnie",
    "Lecimy",
    "Spierdalamy"
  ];

  function randomizeNextButton() {
    const nextButton = document.querySelector(buttonSelector);
    if (nextButton) {
      // Set random phrase as button text
      const randomPhrase = phrases[Math.floor(Math.random() * phrases.length)];
      nextButton.textContent = randomPhrase;

      // Get the current path to use as base URL
      const path = window.location.pathname;
      const segments = path.split('/').filter(Boolean); // Remove empty segments
      
      // Determine if there's a page number at the end of the path
      const isOnPage = !isNaN(segments[segments.length - 1]);
      
      // If already on a specific page, replace the last segment with a new random page number
      if (isOnPage) {
        segments[segments.length - 1] = (Math.floor(Math.random() * 1000) + 1).toString();
      } else {
        // If not on a page, add a new page number to the path
        segments.push((Math.floor(Math.random() * 1000) + 1).toString());
      }

      // Update the button href with the modified path
      nextButton.href = `${window.location.origin}/${segments.join('/')}`;
    }
  }

  // Run the randomization function on page load
  randomizeNextButton();
})();
