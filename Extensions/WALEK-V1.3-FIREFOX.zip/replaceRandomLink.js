(function() {
  const randomLinkSelector = 'a[href="https://jbzd.com.pl/losowe"].pagination-random';
  const replacementImageUrl = "https://i.imgur.com/1ZprDUf.png";

  function replaceRandomLink() {
    const randomLink = document.querySelector(randomLinkSelector);
    if (randomLink) {
      const imgElement = document.createElement("img");
      imgElement.src = replacementImageUrl;
      imgElement.alt = "Wykopaliska Memów";
      imgElement.style.width = "50%";
      imgElement.style.height = "auto";

      // Replace the link content with the image
      randomLink.innerHTML = "";
      randomLink.appendChild(imgElement);
    }
  }

  // Run the replacement function on page load
  replaceRandomLink();
})();
