chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "fetchComments") {
    const apiUrl = `https://jbzd.com.pl/comment/content/listing/${message.contentID}?page=1&per_page=100&sort=newest&local=true`;

    fetch(apiUrl, {
      method: "GET",
      headers: {
        "accept": "application/json",
        "x-requested-with": "XMLHttpRequest",
        "cache-control": "no-cache",
      }
    })
    .then(response => {
      if (!response.ok) throw new Error("Network response was not ok");
      return response.json();
    })
    .then(data => {
      console.log("Comments fetched successfully:", data);
      sendResponse({ success: true, data });
    })
    .catch(error => {
      console.error("Failed to fetch comments:", error);
      sendResponse({ success: false, error: error.message });
    });

    return true; // Keeps the message channel open for async response
  }
});
