document.addEventListener("DOMContentLoaded", () => {
  loadSettings();

  // Event listeners for tab buttons
  document.getElementById("homeButton").addEventListener("click", () => showTab("home"));
  document.getElementById("settingsButton").addEventListener("click", () => showTab("settings"));

  // Event listener for save button
  document.getElementById("saveButton").addEventListener("click", saveSettings);
});

function showTab(tabId) {
  document.querySelectorAll(".tab").forEach(tab => tab.classList.remove("active"));
  document.getElementById(tabId).classList.add("active");
}

function loadSettings() {
  chrome.storage.local.get(["settings"], (data) => {
    const settings = data.settings || {
      replaceImageSrc: true,
      replaceCoinIcon: true,
      replaceTempleOSText: true,
      replaceSearchIcon: true,
      formatCommentAuthorName: true,
      activateDropdowns: true,
      allowTextareaResize: true,
      changeVldBackground: true,
      customizeRecommendations: true,
      replaceNavLogo: true,
      replaceMikroblogLink: true,
      commentEnhancer: true,
    };

    for (const key in settings) {
      document.querySelector(`input[name="${key}"]`).checked = settings[key];
    }
  });
}

function saveSettings() {
  const settings = {};
  document.querySelectorAll("#settingsForm input[type='checkbox']").forEach(input => {
    settings[input.name] = input.checked;
  });

  chrome.storage.local.set({ settings }, () => {
    console.log("Settings saved:", settings);

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        files: ["content.js"]
      });
    });
  });
}
