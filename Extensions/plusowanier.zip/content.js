// Helper function to get a cookie by name
function getCookie(name) {
    let match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    return match ? decodeURIComponent(match[2]) : null;
}

// Helper function to dynamically extract CSRF tokens if stored in meta tags
function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.content : '';
}

// Function to perform the vote
function vote(contentId) {
    return fetch("https://jbzd.com.pl/comment/vote/" + contentId, {
        method: "POST",
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json;charset=UTF-8",
            "X-CSRF-Token": getCsrfToken(),
            "X-Requested-With": "XMLHttpRequest",
            // Add other headers as required by your target API
        },
        body: JSON.stringify({"for": 1}),
        credentials: "include"
    })
    .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
    })
    .then(data => console.log('Voted for content ID:', contentId))
    .catch(error => console.error('Error voting for content ID:', contentId, error.message));
}

// Function to find and vote on new comments with delay
let processedContentIds = new Set(); // Keep track of processed IDs

function findAndVoteOnNewComments() {
    const comments = document.querySelectorAll('.comments .comment');
    const contentIds = Array.from(comments).map(comment => comment.getAttribute('name').replace('komentarz-', ''));
    let index = 0; // Start with the first content ID

    function voteNext() {
        if (index < contentIds.length) {
            const contentId = contentIds[index];
            if (!processedContentIds.has(contentId)) {
                vote(contentId).then(() => {
                    processedContentIds.add(contentId); // Mark as processed
                    index++; // Move to the next content ID
                    setTimeout(voteNext, 2500); // Wait for 5 seconds before the next vote
                }).catch(() => {
                    index++; // Move to the next content ID even if there was an error
                    setTimeout(voteNext, 2500); // Wait for 5 seconds before the next vote
                });
            } else {
                index++; // Skip already processed content ID
                setTimeout(voteNext, 0); // No delay if skipping
            }
        }
    }

    voteNext(); // Start the voting process
}

// Initial call to start the voting process
findAndVoteOnNewComments();

// Set up a repeated check, e.g., every 60 seconds to catch new comments
// Adjust or remove this interval based on your requirements
setInterval(findAndVoteOnNewComments, 20000);

// Scroll down functionality running in parallel
var scrollDownInterval = setInterval(function() {
    window.scrollBy(0, 21); // Scrolls down 21.37 pixels every 100 milliseconds
}, 100);

// There's no built-in mechanism to stop scrolling until the page is refreshed, as requested.
// To manually stop the scrolling, use clearInterval(scrollDownInterval) in the console.
