// background.js
// This can be left empty if not used for other background tasks.
