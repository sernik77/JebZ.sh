// Add this listener setup to your clickSubmitButton.js or a new script fil
// Wait for a message from the background script to execute the main function
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if(message.action === "executeClick") {
        clickSubmitButton();
    }
});
function clickSubmitButton() {
    // Your existing clickSubmitButton function code
var buttons = document.querySelectorAll('button.btn-submit[type="submit"]');
var targetButton = Array.from(buttons).find(button => button.textContent.trim() === "Dodaj");

if(targetButton) {
  targetButton.click();
  console.log('Button clicked successfully!');
} else {
  console.error('Button not found');
}}
